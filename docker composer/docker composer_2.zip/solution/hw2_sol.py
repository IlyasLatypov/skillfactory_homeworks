import pickle

from flask import Flask, request, jsonify

with open('hw1.pkl', 'rb') as f:
    model = pickle.load(f)

app = Flask(__name__)


@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    return jsonify({'prediction': model.predict([data])[0]})


if __name__ == '__main__':
    app.run('0.0.0.0')
